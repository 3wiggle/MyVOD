//Strings, that may be translated. please change only the text beween ''.

// English -----

var str1Film = 'Film';
var strFilme = 'Films';
var strZufallsfilm = 'Random Film';
var strAlleFilme = 'All Films';
var strNeueFilme = 'New Films';
var strFilter = 'Search:';
var strGesehen = 'Seen';
 